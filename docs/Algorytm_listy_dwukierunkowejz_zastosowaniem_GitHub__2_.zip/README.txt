DOKUMENTACJA PROJEKTU LISTY DWUKIERUNKOWEJ

WAŻNE: w swoim pop_front() przywróć size--; bezpośrednio po delete temp;.
Gotowa wersja pliku z tą jedną korektą znajduje się w kod/DoublyLinkedList.cpp.

PLIK GŁÓWNY I KOMPILACJA
Otwórz dokument.tex jako plik główny. Wszystkie źródła są zapisane w UTF-8.
Kompilator dokumentacji: pdfLaTeX. Bibliografia: BibTeX (nie Biber).
W katalogu zawierającym dokument.tex wykonaj:
  pdflatex dokument.tex
  bibtex dokument
  pdflatex dokument.tex
  pdflatex dokument.tex
Alternatywnie: latexmk -pdf dokument.tex
Zachowaj cały katalog razem: pliki tex/, rys/, kod/ i obie preambuły są potrzebne.
Diagramy rysowane są przez TikZ, bez dodatkowego programu i bez shell-escape.

STRUKTURA
- dokument.tex: strona tytułowa, spis treści i kolejność rozdziałów;
- preambula_pakiety.tex, preambula_ustawienia.tex: pakiety i formatowanie;
- strona_tytulowa.sty: układ strony tytułowej z szablonu;
- tex/rozdzial1.tex do tex/rozdzial5.tex: wszystkie pięć rozdziałów;
- rys/: diagram klas, przykład wstawiania i logo zachowane z szablonu;
- kod/: pliki projektu potrzebne do listingów i zapis wyjścia main.cpp;
- bibliografia.bib: źródła wykorzystane do opracowania dokumentacji.

ZAKRES UZUPEŁNIENIA
Wypełniono wymagania, instalację i uruchamianie, analizę algorytmu,
przykład ręczny, złożoność, opis środowiska, diagram klas, Git/GitHub,
implementację, rzeczywiste wyniki programu,
rozpoznane ograniczenia i wnioski. Nie ma pustych punktów merytorycznych.

CO SPRAWDZIĆ PRZED ODDANIEM
Nie ma obowiązkowych miejsc oznaczonych do ręcznego dopisania.
Na stronie tytułowej zachowano dane z poprzedniego ZIP-a i szablonu:
- autor: Jakub Pyrdoł;
- rok: 2026;
- prowadzący: mgr inż. Dawid Kotlarski;
- uczelnia i przedmiot: zgodnie z przekazanym szablonem.
Jeżeli prowadzący wymaga innych danych, zmień odpowiednie polecenia
w początkowej części dokument.tex. Numeru indeksu ani grupy nie dodawano,
ponieważ nie ma takich pól w przekazanym szablonie.

KOD PROJEKTU
Źródła pochodzą z aktualnego archiwum ListaDwukierunkowa_Pyrdol_Jakub(2).zip.
Uwzględniono destruktor, zablokowanie kopiowania i reset kursora podczas usuwania.

WAŻNE - JEDNA LINIA DO PRZENIESIENIA DO TWOJEGO PROJEKTU
W przesłanej wersji pop_front() brakowało instrukcji size--; po delete temp;.
W kopii kod/DoublyLinkedList.cpp przywrócono tę pojedynczą instrukcję.
To jedyna korekta kodu aplikacji względem aktualnego archiwum (poza końcami linii).
Możesz skopiować kod/DoublyLinkedList.cpp do swojego projektu albo dopisać:

    delete temp;
    size--;

na końcu pop_front(). Bez zmniejszania licznika kolejne operacje indeksowe mogą
uznać nieistniejący element za poprawny. Opis i wyniki programu w dokumentacji
odpowiadają wersji z przywróconą instrukcją size--;.
Pozostałych plików aplikacji nie zmieniano.

Plik wynik_main.txt zawiera zapis wyjścia programu demonstracyjnego main.cpp.
CMakeLists.txt wskazuje źródła aplikacji.

Informacje o środowisku Windows/CLion/MinGW pochodzą z konfiguracji projektu.
Złożoności w tekście są analizą kodu, a nie pomiarem czasu.
